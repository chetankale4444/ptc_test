package com.ptc.plms.gol.oops.rules.service;

import com.ptc.plms.gol.oops.Cell;
import com.ptc.plms.gol.oops.State;

public class StateUtil {

	public static State deadState(int liveNeighbours) {

		if (liveNeighbours == 3) {
			return State.LIVE;
		}

		return State.DEAD;
	}

	public static State liveState(int liveNeighbours) {

		if (liveNeighbours == 2 || liveNeighbours == 3) {
			return State.LIVE;
		} else
			return State.DEAD;
	}
	
	public static Cell createCopy(Cell c) {
		return new Cell(c.getX(),c.getY(),c.getState());
	}

	
}
