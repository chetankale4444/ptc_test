package com.ptc.plms.gol.oops.rules;

import com.ptc.plms.gol.oops.State;
import com.ptc.plms.gol.oops.rules.service.StateUtil;

/**
 * 
 * @author hdhingra
 *
 */
public class RuleImpl implements Rule{

	@Override
	public State nextState(State currentState, int liveNeighbours) {
		
		/*
		 * if(State.LIVE.equals(currentState)) { if(liveNeighbours==2 ||
		 * liveNeighbours==3) { return State.LIVE; } else return State.DEAD; } else
		 * if(State.DEAD.equals(currentState)) { if(liveNeighbours == 3) { return
		 * State.LIVE; } }
		 * 
		 * return currentState;
		 */
		
		if(State.LIVE.equals(currentState))
		{
			return currentState = StateUtil.liveState(liveNeighbours);
		}
		else if(State.DEAD.equals(currentState)) 
		{
			return currentState = StateUtil.deadState(liveNeighbours);
		}
		
		return currentState;
	}

}
