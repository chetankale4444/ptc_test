package com.ptc.plms.gol.oops.rules.service;

import java.util.Set;

import com.ptc.plms.gol.oops.Cell;
import com.ptc.plms.gol.oops.GameStratedy;

public interface ILiveNeighbour {
	public int findLiveNeighbourCount(Cell cell,Set<Cell> liveCells,GameStratedy gameStratedy);

}
