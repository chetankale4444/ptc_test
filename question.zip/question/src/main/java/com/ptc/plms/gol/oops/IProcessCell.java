package com.ptc.plms.gol.oops;

import java.util.Set;

public interface IProcessCell {
	
	public void processCell(Cell cell,Set<Cell> currentGeneration,Set<Cell> nextGeneration,RuleRunner ruleRunner);

}
