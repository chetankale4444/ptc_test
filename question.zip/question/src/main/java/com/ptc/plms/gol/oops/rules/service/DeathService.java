package com.ptc.plms.gol.oops.rules.service;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.ptc.plms.gol.oops.Cell;
import com.ptc.plms.gol.oops.State;

public class DeathService implements IDeathService {
	
	public Set<Cell> filterDead(HashSet<Cell> nextGeneration) {
		Iterator<Cell> iterator = nextGeneration.iterator();
		
		while(iterator.hasNext())
		{
			if(State.DEAD.equals(iterator.next().getState()))
			{
				iterator.remove();
			}
		}
		
		return nextGeneration;
	}

}
