package com.ptc.plms.gol.oops.data;

import com.ptc.plms.gol.oops.rules.Rule;

public class RuleData {
	
	public RuleData() {
		
	}
	
	public RuleData(Rule[] rules) {
		this.rules = rules;
	}
	
	private Rule [] rules; 
	
	public void setRules(Rule[] rules) {
		this.rules = rules;
	}
	
	public Rule[] getRules() {
		return rules;
	}

}
