package com.ptc.plms.gol.oops.rules.service;

import java.util.HashSet;
import java.util.Set;

import com.ptc.plms.gol.oops.Cell;

public interface IDeathService {
	
	public Set<Cell> filterDead(HashSet<Cell> nextGeneration);

}
