package com.ptc.plms.gol.oops.rules.service;

import java.util.Set;

import com.ptc.plms.gol.oops.Cell;
import com.ptc.plms.gol.oops.GameStratedy;
import com.ptc.plms.gol.oops.State;

public class LiveNeighbourImpl  implements ILiveNeighbour{
	
	public int findLiveNeighbourCount(Cell cell,Set<Cell> liveCells,GameStratedy gameStratedy)
	{
		int count=0;
		for(Cell c:gameStratedy.findNeighbours(cell, liveCells))
		{
			if(State.LIVE.equals(c.getState())) count++;
		}
		return count;
	}

}
