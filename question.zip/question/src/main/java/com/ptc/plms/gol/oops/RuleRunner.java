package com.ptc.plms.gol.oops;

import java.util.HashSet;
import java.util.Set;
import com.ptc.plms.gol.oops.impl.ProcessCellImpl;
import com.ptc.plms.gol.oops.rules.service.DeathService;


public class RuleRunner {
	
	private GameStratedy gameStratedy;
	private IProcessCell iProcessCell;

	public RuleRunner(GameStratedy gameStratedy)
	{
		this.gameStratedy = gameStratedy;
		this.iProcessCell = new ProcessCellImpl();
	}

	public Set<Cell> applyRules(Set<Cell> liveCells) {
		HashSet<Cell> nextGeneration=new HashSet<Cell>(); 
		
		Set<Cell> neighbouringCells;
		RuleRunner ruleRunner = new RuleRunner(gameStratedy);
		for(Cell cellFromCurrentGeneration: liveCells)
		{
			iProcessCell.processCell(cellFromCurrentGeneration,liveCells,nextGeneration,ruleRunner );
			
			neighbouringCells=gameStratedy.findNeighbours(cellFromCurrentGeneration, liveCells);
			
			for(Cell neighbouringCell:neighbouringCells)
			{
				iProcessCell.processCell(neighbouringCell,liveCells,nextGeneration,ruleRunner );
			}
		}
		
		return new DeathService().filterDead(nextGeneration);
	}
	
	/*private Set<Cell> filterDead(HashSet<Cell> nextGeneration) {
		Iterator<Cell> iterator = nextGeneration.iterator();
		
		while(iterator.hasNext())
		{
			if(State.DEAD.equals(iterator.next().getState()))
			{
				iterator.remove();
			}
		}
		
		return nextGeneration;
	}*/

	/*
	private void processCell(Cell cell,Set<Cell> currentGeneration,Set<Cell> nextGeneration)
	{
		if(nextGeneration.contains(cell)) return; // already processed
		
		cell=StateUtil.createCopy(cell);
		
		State nextState=cell.getState();
		for(Rule rule:gameStratedy.getRules())
		{
			//nextState=rule.nextState(cell.getState(), findLiveNeighbourCount(cell, currentGeneration));
			
			nextState=rule.nextState(cell.getState(), LiveNeighbour.findLiveNeighbourCount(cell, currentGeneration,getGameStratedy()));
			
			if(!cell.getState().equals(nextState))
			{
				break;
			}
		}
		
		cell.setState(nextState);
		nextGeneration.add(cell);
	} */
	
	/*private int findLiveNeighbourCount(Cell cell,Set<Cell> liveCells)
	{
		int count=0;
		for(Cell c:gameStratedy.findNeighbours(cell, liveCells))
		{
			if(State.LIVE.equals(c.getState())) count++;
		}
		return count;
	}*/


	public GameStratedy getGameStratedy() {
		return gameStratedy;
	}


	public void setGameStratedy(GameStratedy gameStratedy) {
		this.gameStratedy = gameStratedy;
	}
	
	public IProcessCell getiProcessCell() {
		return iProcessCell;
	}


	public void setiProcessCell(IProcessCell iProcessCell) {
		this.iProcessCell = iProcessCell;
	}

}
