package com.ptc.plms.gol.oops.impl;

import java.util.Set;

import com.ptc.plms.gol.oops.Cell;
import com.ptc.plms.gol.oops.GameStratedy;
import com.ptc.plms.gol.oops.IProcessCell;
import com.ptc.plms.gol.oops.RuleRunner;
import com.ptc.plms.gol.oops.State;
import com.ptc.plms.gol.oops.rules.Rule;
import com.ptc.plms.gol.oops.rules.service.LiveNeighbourImpl;
import com.ptc.plms.gol.oops.rules.service.StateUtil;

public class ProcessCellImpl implements IProcessCell {

	@Override
	public void processCell(Cell cell, Set<Cell> currentGeneration, Set<Cell> nextGeneration,RuleRunner ruleRunner) {
       if(nextGeneration.contains(cell)) return; // already processed
		
		cell=StateUtil.createCopy(cell);
		
		State nextState=cell.getState();
		LiveNeighbourImpl liveNeighbour = new LiveNeighbourImpl();
		for(Rule rule:ruleRunner.getGameStratedy().getRules())
		{
			nextState=rule.nextState(cell.getState(), liveNeighbour.findLiveNeighbourCount(cell, currentGeneration,ruleRunner.getGameStratedy()));
			
			if(!cell.getState().equals(nextState))
			{
				break;
			}
		}
		
		cell.setState(nextState);
		nextGeneration.add(cell);
	}

}
